# Copyright (c) Facebook, Inc. and its affiliates. All Rights Reserved.

from .utils.env import setup_environment

setup_environment()


__version__ = "0.1"
