
## Some scripts for developers to use, include:

- `linter.sh`: lint the codebase before commit
- `run_{inference,instant}_tests.sh`: run inference/training for a few iterations.
- `parse_results.sh`: parse results from log file.
